while sleep 0.5; do
curl 10.0.2.100 &
curl 10.0.2.100 &
curl 10.0.2.100;
done